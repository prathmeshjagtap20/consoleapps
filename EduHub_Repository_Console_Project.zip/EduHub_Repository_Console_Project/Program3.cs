// using System;
// using EduHub_Repository_Console_Project.Models;
// using EduHub_Repository_Console_Project.Repository;
// namespace EduHub_Repository_Console_Project
// {
//     class Program3
//     {
//         static void Main(string[] args)
//         {




//         }
//     }
// }